package ru.bagabiev.bagabiev_task3;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class SumController {

    @FXML
    private TextField dTextField;

    @FXML
    private TextField lTextField;

    @FXML
    private Button result;

    @FXML
    private TextField sTextField;

    @FXML
    private Label tatar;

    @FXML
    private Label timur;

    @FXML
    private Label tugan;



}
