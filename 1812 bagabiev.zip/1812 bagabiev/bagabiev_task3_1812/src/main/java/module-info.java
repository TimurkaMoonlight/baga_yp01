module ru.bagabiev.bagabiev_task3_1812 {
    requires javafx.controls;
    requires javafx.fxml;


    opens ru.bagabiev.bagabiev_task3_1812 to javafx.fxml;
    exports ru.bagabiev.bagabiev_task3_1812;
}