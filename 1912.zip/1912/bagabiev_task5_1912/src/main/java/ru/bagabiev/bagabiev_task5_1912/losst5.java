package ru.bagabiev.bagabiev_task5_1912;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.InputStream;

public class losst5 {

    @FXML
    private ImageView Imagee;

    @FXML
    private Label result;

    @FXML
    private TextField xText;

    @FXML
    private TextField yText;

    @FXML
    void button(ActionEvent event) {
        try {
            double x = Double.parseDouble(xText.getText());
            double y = Double.parseDouble(yText.getText());

            double radius = 5;
            double distance = Math.sqrt(x * x + y * y);

            if (Math.abs(distance - radius) < 0.0001) {
                result.setText("На границе");
            }
            else if (distance < radius) {
                result.setText("Да");
            }
            else {
                result.setText("Нет");
            }
        }
        catch (NumberFormatException e) {
            result.setText("Некорректный ввод");
        }

    }

    }

